export const msalConfig = {
    auth: {
        clientId: process.env.PUBLIC_CLIENT_ID,
        authority: process.env.PUBLIC_INSTANCE,
        redirectUri: "/auth",
        postLogoutRedirectUri: "/",
        scope: process.env.PUBLIC_SCOPES,
        domain: "mealmasterbot",
    },
    cache: {
        cacheLocation: 'localStorage',
        storeAuthStateInCookie: true,
    },
};

export const loginRequest = {
    scopes: [process.env.PUBLIC_SCOPES]
};

export const userDataLoginRequest = {
    scopes: ["user.read"]
};

export const graphConfig = {
    graphMeEndpoint: "https://graph.microsoft.com/v1.0/me"
};